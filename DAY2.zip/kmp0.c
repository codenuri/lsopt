#include <stdio.h>
#include <string.h>

// "knuth, mooyer string search algorithm"

// 문자열(S) 에서 부분문자열(W) 찾기. 답은 15
// 
//			01234567890123456789012
char S[] = "abc abcdab abcdabcdabde";
char W[] =         "abcdabd";

const int s_size = 23;
const int w_size = 7;

int main()
{
	int flag = 0;
	
	// i * j 루프!
	for (int i = 0; i < s_size; i++)
	{
		for ( int j = 0; j < w_size; j++)
		{
			if ( S[i+j] != W[j] ) // 다른 문자라면 탈출
				break;
			else 
			{
				if ( j == w_size - 1)
				{
					printf("find : %d\n", i);
					flag = 1;
					break;
				}
			}
		}
		if ( flag) break;
	}
}


// fail 함수 : 주어진 문자열의 [0, N] 구간에서
//			  접두어와 접미어중 중복된 문자열의 최대 갯수 

// 문자열이 "abcdabd" 인 경우의 fail 함수
// fail(N) 은 [0, N] 번째 문자열
// fail(0) "a"			=> 0
// fail(1) "ab"			=> 0
// fail(2) "abc"		=> 0
// fail(3) "abcd"		=> 0
// fail(4) "abcda"		=> 1
// fail(5) "abcdab"		=> 2
// fail(6) "abcdabd"	=> 0

// j = 6 에서 실패한 경우
// i이동값 : j - fail(j-1) ==> 6 - fail(5) => 6 - 2 = 4
// J의시작 : fail(j-1) = 2