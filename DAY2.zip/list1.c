﻿// list1.c
#include <stdio.h>
#include <stdlib.h>

typedef struct _NODE
{
	int data;
	struct _NODE *next;
} NODE;

NODE *head = 0;

void insert_front(int data)
{
	
}

int main()
{
	insert_front(1);
	insert_front(2);
	insert_front(3);
	insert_front(4);
}











