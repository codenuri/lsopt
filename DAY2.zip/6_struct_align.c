#include "counter.h"

typedef struct _packet1
{
	char cmd;
	int data;
} PACKET1;

typedef struct _packet2
{
	char cmd;
	int data;
} PACKET2;


int main()
{
	printf("%lld\n", sizeof(PACKET1)); 
	printf("%lld\n", sizeof(PACKET2)); 

	PACKET1 pack1 = { 0 };
	PACKET2 pack2 = { 0 };

}




