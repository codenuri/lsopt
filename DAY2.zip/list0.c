#include <stdio.h>


int main()
{
	int n = 0;

	while(1)
	{
		scanf_s("%d", &n);

		if ( n == -1 ) break;
	
		// 사용자가 입력한 값을 메모리에 보관해야 한다.
	}
}