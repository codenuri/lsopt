#include <stdio.h>
#include <string.h>

// 1. 문자열에서 한문자 찾기
char S[] = "abc abcdab abcdabcdabde";
char D = 'd';

const int s_size = 23;

int main()
{
	int i = 0;



	printf("%d\n", i);
}


