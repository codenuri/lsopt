#include "counter.h"

#include <stdio.h>
#include <string.h>



char S[] = "abc abcdab abcdabcdabde";
char W[] = "abcdabd";

const int s_size = 23;
const int w_size = 7;


void bad()
{
	int flag = 0;

	for (int i = 0; i < s_size; i++)
	{
		for (int j = 0; j < w_size; j++)
		{
			if (S[i + j] != W[j])
				break;
			else
			{
				if (j == w_size - 1)
				{
					printf("find : %d\n", i);
					flag = 1;
					break;
				}
			}
		}
		if (flag) break;
	}


}





int fail[8] = { 0 };

void init_fail()
{
	for (int i = 1, j = 0; i < w_size; i++)
	{
		while (j > 0 && W[i] != W[j])
			j = fail[j - 1];

		if (W[i] == W[j])
			fail[i] = ++j;
	}
}

void good()
{
	init_fail();

	int j = 0;

	for (int i = 0; i < s_size; ++i) 
	{
		while (j > 0 && S[i] != W[j])
			j = fail[j - 1];

		if (S[i] == W[j])
		{
			if (j == w_size - 1)
			{
				printf("find : %d\n", i - w_size + 1);
				break;
			}
			else
				j++;
		}
	}
}


int main()
{
	CHECK(START);
	bad();
	CHECK(LAB);
	good();
	CHECK(END);
}

// �� �˰������� �̸��� "knuth, mooyer �� ���ڿ� �˻� �Դϴ�."