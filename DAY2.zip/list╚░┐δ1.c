﻿#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct _People
{
	char name[12];
	int  age;
} People;

int main()
{
	int age = 0;
	char name[12];
	People *pPeople;

	while ( 1 )
	{
		printf("나이를 먼저 입력하세요 >> ");
		scanf_s("%d", &age);

		if (age == -1) break;

		printf("이름을 입력하세요 >> ");
		scanf_s("%s", name);
	}
}




