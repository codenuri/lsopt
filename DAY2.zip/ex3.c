#include <stdio.h>

int main()
{
	// 사용자가 -1일 입력할때 까지 계속 입력 받고싶다.

	int n = 0;
	
	while( 1 )
	{
		scanf_s("%d", &n);

		if ( n == -1 ) break;
	}		
}