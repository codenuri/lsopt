#pragma once
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

	extern const int START;
	extern const int END;
	extern const int LAB;

	void CHECK(const int check);


#ifdef __cplusplus
}
#endif
