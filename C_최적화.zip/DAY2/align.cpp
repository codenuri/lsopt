// align.cpp
#include <stdio.h>

int a1 = 0;
int a2 = 0;
//int a3 = 0;	
int a4 = 0;

alignas(64) int a3 = 0;
//alignas(64) int a4 = 0;


int main()
{
	printf("%p\n", &a1);
	printf("%p\n", &a2);
	printf("%p\n", &a3);
	printf("%p\n", &a4);
}