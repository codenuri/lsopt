// add.c
#include "add.h"

int add1(int a, int b)
{
    return a + b;
}
/*
__inline int add2(int a, int b)
{
    return a + b;
}
*/