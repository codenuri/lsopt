#include "counter.h"


int sum1(int n)
{
	if (n == 1) return 1;
	return n + sum1(n - 1);
}

int sumTail(int n, int result)
{
	if (n == 1) return result;
	return sumTail(n - 1, result + n);
}
int sum2(int n)
{
	return sumTail(n, 1);
}

int sum3(int n)
{
	int s = 0;

	for (int i = 0; i <= n; ++i)
		s += i;
	return s;
}

int main()
{
	int cnt = 110000;

	CHECK(START); 	int ret1 = sum1(cnt);
	CHECK(LAB);     int ret2 = sum2(cnt);
	CHECK(LAB);     int ret3 = sum3(cnt);
	CHECK(END);

	printf("%d\n", ret1);
	printf("%d\n", ret2);
	printf("%d\n", ret3);
}