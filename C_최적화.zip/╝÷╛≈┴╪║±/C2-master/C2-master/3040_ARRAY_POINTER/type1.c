int Add(int a, int b); // int(int, int)

int main(void)
{
    int    n = 10;
    double d = 3.4;

    int x[3] = {1,2,3};
    int y[3][2];
}

int Add(int a, int b)
{
    return a + b;
}
