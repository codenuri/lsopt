// call.c

void foo() {}   ret

int main(void)
{
    foo();  // call _foo
}
