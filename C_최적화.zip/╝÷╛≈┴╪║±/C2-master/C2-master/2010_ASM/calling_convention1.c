
void foo(int a, int b)
{
}

int main(void)
{
    foo(1, 2);
}
