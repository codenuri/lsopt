#include <stdio.h>

/*
void foo( ...)
{
}
*/
int main(void)
{
    //foo(3, 1, 2, 3);

    int n = 10;
    printf("%d\n", n);
    printf("%d %d %d\n", n);
    printf("hello\n", n);
}
