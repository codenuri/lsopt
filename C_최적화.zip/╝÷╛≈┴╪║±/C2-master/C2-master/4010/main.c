#include "square.h"

int main(void)
{
    square(3);
    // windows : call _square
    // linux : call square
}
