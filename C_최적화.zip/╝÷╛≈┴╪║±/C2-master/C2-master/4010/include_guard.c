#include "Point2.h"
#include "Point2.h"


int main(void)
{
    POINT pt;
}
