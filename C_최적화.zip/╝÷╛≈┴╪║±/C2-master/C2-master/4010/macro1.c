#include <stdio.h>

#define MAX 256
#define SQUARE(n) n * n

int main(void)
{
    char name[MAX];
    
    int n2 = SQUARE(3);
}
