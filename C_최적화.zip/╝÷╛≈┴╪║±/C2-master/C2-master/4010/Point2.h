#pragma once

struct _Point
{
    int x;
    int y;
};
typedef struct _Point POINT;
