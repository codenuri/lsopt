#include <stdio.h>

#define PRESS_ENTER_KEY()    do { printf("press enter key");  \
                             getchar(); } while(0)

int main(void)
{
    //PRESS_ENTER_KEY()

    //if ( 0 )
    //    PRESS_ENTER_KEY();

    if ( 0 )
        PRESS_ENTER_KEY();
    else
    {
    }

    printf("end main\n");
}













//
