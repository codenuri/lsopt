#ifndef POINT1_H
#define POINT1_H

struct _Point
{
    int x;
    int y;
};
typedef struct _Point POINT;

#endif // POINT1_H
