//#include <stdio.h>
#define MAX 256
#define SQUARE(n) ((n) * (n))

int main(void)
{
    char name[MAX];

    int a = 3;
    int n1 = SQUARE(++a);

//    printf("%d\n", n1);
}
