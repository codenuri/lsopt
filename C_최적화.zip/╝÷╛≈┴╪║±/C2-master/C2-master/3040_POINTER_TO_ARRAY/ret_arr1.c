int f1()
{
    int n = 10;
    return n;
}

//int a;
//int foo();
//int foo(int a, int b)[3];


int f2()[3]     // error
{
    int x[3] = {1,2,3}
    return x;   // �迭 ��ȯ
}

int main(void)
{
    int    n = 0;
    double d = 0;

    int x[3] = {1,2,3};

    //int[3] x = {1,2,3};
}



















//
