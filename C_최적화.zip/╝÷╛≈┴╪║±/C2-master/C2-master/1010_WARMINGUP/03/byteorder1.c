#include <stdio.h>

int main(void)
{
    int n1 = 0x11223344;

    int n2 = 0x44; // 00 00 00 44
                   // 44 00 00 00
}
