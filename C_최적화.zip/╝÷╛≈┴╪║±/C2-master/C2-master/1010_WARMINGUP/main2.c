#include <stdio.h>

int foo()
{
}

int main(void)
{
    int n = foo();
    printf("result : %d\n", n);
    //return 0;
}
















//
