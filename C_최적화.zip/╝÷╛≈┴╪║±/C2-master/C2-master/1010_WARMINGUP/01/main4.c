//#include "add.h"

inline int Add(int a, int b)
{
    return a + b;
}

int main(void)
{
    int n = Add(1,2);
}
