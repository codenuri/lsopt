#include "goo.h"



int main(void)
{
    cnt = 10;
    goo();
//    hoo();
    int n = c;
    //int n = MAX;
}
