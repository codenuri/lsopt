#include <stdio.h>

void foo(int a)
{
    printf("foo : %d\n", a);
}
