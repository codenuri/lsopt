const int c = 10;


#define MAX 100

int cnt = 0;
void goo() { }

static void hoo() {}
static int cnt2 = 0;
