#include "linkage.h"

int main(void)
{
    int n = MAX;
    cnt = 10;
    goo();
}
