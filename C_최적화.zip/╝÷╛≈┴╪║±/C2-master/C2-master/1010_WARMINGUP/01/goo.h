void goo();
extern int cnt;
static void hoo();
extern const int c;
