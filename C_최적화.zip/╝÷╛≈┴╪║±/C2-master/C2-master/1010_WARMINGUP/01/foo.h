// foo.h
void foo(int a);
