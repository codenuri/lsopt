#include <stdio.h>

#define MAX 256

int main(void)
{
    char msg[MAX] = "Hello";

    printf("%s\n", msg);
}
