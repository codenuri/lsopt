#include "foo.h"

int main(void)
{
    foo();
    //foo( 10 );
}
