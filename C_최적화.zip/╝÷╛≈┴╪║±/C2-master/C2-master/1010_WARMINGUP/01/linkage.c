#include "linkage.h"

void foo()
{
    int n = MAX;
    goo();
    cnt = 20;
}
