//int g[1024000] = {1,2,3};

int g[1024000];

int main(void)
{
    g[0] = 1;
}
