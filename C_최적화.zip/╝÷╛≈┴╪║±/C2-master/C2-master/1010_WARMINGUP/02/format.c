#include <stdio.h>

int main(void)
{
    char s1[] = "Hello";
    char *s2  = "Hello";
}
