#include <iostream>
#include <thread>
#include <mutex>
#include <exception>

// �ٽ� : mutex ���� �� lock_guard�� ��� ����ϼ���..

std::mutex m;

void foo()
{
//	std::lock_guard<std::mutex> lg(m); // �����ڿ��� lock


	// std::adopt_lock_t : Ÿ��
	// std::adopt_lock   : ��ü
//	m.lock();
//	std::lock_guard<std::mutex> lg(m, std::adopt_lock); // �����ڿ��� lock ��������.

	// c++17 �̶��
	m.lock();
	std::lock_guard lg(m, std::adopt_lock);

	std::cout << "using shared data" << std::endl;
}

int main()
{
	std::thread t1(foo);
	std::thread t2(foo);
	t1.join();
	t2.join();
}



/*
template <class _Mutex>
class lock_guard { 
public:
    using mutex_type = _Mutex;

    explicit lock_guard(_Mutex& _Mtx) : _MyMutex(_Mtx) { // construct and lock
        _MyMutex.lock();
    }

    lock_guard(_Mutex& _Mtx, adopt_lock_t) : _MyMutex(_Mtx) {} // construct but don't lock

    ~lock_guard() noexcept {
        _MyMutex.unlock();
    }

    lock_guard(const lock_guard&) = delete;
    lock_guard& operator=(const lock_guard&) = delete;
private:
    _Mutex& _MyMutex;
};
*/