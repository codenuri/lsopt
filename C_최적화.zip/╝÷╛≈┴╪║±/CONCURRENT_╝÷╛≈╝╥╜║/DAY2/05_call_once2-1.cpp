#include <iostream>
#include <thread>
#include <mutex>
using namespace std::literals;

class Singleton
{
private:
    Singleton() = default;
    static Singleton* sinstance;

    static std::once_flag create_flag;
public:
    Singleton(const Singleton&) = delete;
    Singleton& operator=(const Singleton&) = delete;

    static Singleton* getInstance()
    {
        //initSingleton();

        std::call_once(create_flag, initSingleton);
        return sinstance;
    }

    // ��Ƽ ������ ȯ�濡���� �Ʒ� �Լ��� �ѹ��� ȣ����� �����ؾ� �մϴ�.
    static void initSingleton()
    {
        std::cout << "              Create Singleton Object" << std::endl;
        sinstance = new Singleton;
    }
};
Singleton* Singleton::sinstance = nullptr;
std::once_flag Singleton::create_flag;

void foo()
{
    auto p1 = Singleton::getInstance();
    auto p2 = Singleton::getInstance();

    std::cout << std::this_thread::get_id() << " : " << p1 << std::endl;
    std::cout << std::this_thread::get_id() << " : " << p2 << std::endl;
}

int main()
{
    std::thread t1(foo);
    std::thread t2(foo);
    t1.join();
    t2.join();
}



