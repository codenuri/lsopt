#include <iostream>

// exception safety 

class Point {};

template<typename T> class Stack
{
	T buff[10];
	int idx = 0;
public:
	void push(const T& a)
	{
		buff[idx++] = a;
	}
	T pop()
	{
		--idx;
		return buff[idx];
	}
};

int main()
{
	Stack<Point> s;

	Point pt;
	
	s.push(pt);

	Point pt = s.pop();
}
