#include <exception>
#include <stack>
#include <mutex>
#include <memory>
#include <iostream>

struct empty_stack : std::exception
{
    const char* what() const throw()
    {
        return "empty stack";
    }
};

template<typename T> class threadsafe_stack
{
private:
    std::stack<T> data;
    std::mutex m;
public:
    threadsafe_stack() {}
};

threadsafe_stack<int> ts;

int main()
{
    threadsafe_stack<int> s1;
    threadsafe_stack<int> s2 = s1;
    s2 = s1;

    s1.push(10);
    
    if ( s1.empty() ) 
    {
    }



}
