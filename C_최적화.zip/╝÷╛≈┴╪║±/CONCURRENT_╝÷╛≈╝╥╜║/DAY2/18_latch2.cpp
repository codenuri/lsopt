#include <iostream>
#include <mutex>
#include <latch>
#include <thread>

std::latch sync_point{ 3 }; // 1ȸ�� ����..

void foo(std::string name)
{
	std::cout << "start  work : " << name << std::endl;
	std::cout << "finish work : " << name << std::endl;

//	sync_point.count_down();		// --count �Ŀ� ���!!
	sync_point.arrive_and_wait();   // --count �ϰ�, count == 0 �� �ɶ��� ���

	std::cout << "have dinner : " << name << std::endl;
}

int main()
{
	std::jthread t1(foo, "kim"), t2(foo, "lee"), t3(foo, "park");

}
