#include <iostream>
#include <stack>
#include <mutex>
#include <thread>

std::stack<int> s;

void foo()
{
	int n = s.top();
	s.pop();
	std::cout << n << std::endl;
}

void goo()
{
	int n = s.top();
	s.pop();
	std::cout << n << std::endl;
}

int main()
{
	std::thread t1(&foo);
	std::thread t2(&goo);

	t1.join();
	t2.join();
}