#include <iostream>
#include <mutex>
#include <latch> // C++20
#include <thread>
#include <barrier>  // C++20

void oncomplete() noexcept
{
	std::cout << "======================oncomplete=================" << std::endl; 
}

//std::latch sync_point{ 3 }; // 1ȸ�� ����..
std::barrier sync_point{ 3, oncomplete };  // ������ ��밡��.


void foo(std::string name)
{
	std::cout << "start  work : " << name << std::endl;
	std::cout << "finish work : " << name << std::endl;

	sync_point.arrive_and_wait();

	std::cout << "have dinner : " << name << std::endl;

	sync_point.arrive_and_wait(); 

	std::cout << "go home : " << name << std::endl;
}

int main()
{
	std::jthread t1(foo, "kim"), t2(foo, "lee"), t3(foo, "park");

}
