#include <iostream>
#include <vector>

class Test
{
public:
	Test() {}

	Test(const Test& t) = delete;
	Test(Test&&) {}
};

int main()
{
	Test t1;
//	Test t2 = t1;			 // ���� ������
//	Test t3 = std::move(t1); // move ������
	Test t4 = Test(); 

	std::vector<Test> v;

//	v.push_back(t1);
	v.push_back(Test());
	v.emplace_back( );
}