#include <iostream>
#include <algorithm>
#include <vector>
#include <thread>
#include <execution>
#include <mutex>
#include <chrono>
using namespace std::literals;

int main()
{
    std::vector<int> v(10000, 0);

    for (int i = 1; i <= 10000; i++)
        v.push_back(i);

    int sum = 0;

    // �Ʒ� �ڵ�� �̱� ������ �̹Ƿ� �����մϴ�.
//  std::for_each( v.begin(), v.end(), [&](int n) { sum += n; });
       
//  std::for_each(std::execution::par, v.begin(), v.end(), [&](int n) { sum += n;});

    // ��� 1. mutex �� ���.
    /*
    std::mutex m;
    std::for_each(std::execution::par, v.begin(), v.end(), 
        [&](int n) 
        { 
            std::lock_guard<std::mutex> lg(m);
            sum += n; 
        });
    */

    // ��� 2. sum ������ atomic ����
    std::atomic<int> sum2{ 0 };
    std::for_each(std::execution::par, v.begin(), v.end(), [&](int n) { sum2 += n; });
      
    std::cout << sum2 << '\n';
}