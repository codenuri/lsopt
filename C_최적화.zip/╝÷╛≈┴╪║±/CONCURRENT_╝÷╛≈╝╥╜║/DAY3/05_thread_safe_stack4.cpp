#include <exception>
#include <stack>
#include <mutex>
#include <memory>
#include <iostream>

// ����� ���� ���� Ŭ���� ���鶧
// 1. std::exception ���� �Ļ� �޾Ƽ� ���弼��.
// 2. what() �����Լ� ������ �ؼ� ������ ������ ��ȯ�ϰ� �ϼ���.

struct empty_stack : std::exception
{
    const char* what() const throw()
    {
        return "empty stack";
    }
};

template<typename T, typename Mutex = std::mutex >
class Stack
{
private:
    std::stack<T> data;
    mutable Mutex  m;
    std::condition_variable cv;
public:
    void push(const T& new_value)
    {
        {
            std::lock_guard<Mutex> lg(m);
            data.push(new_value);
        }
        cv.notify_one();
    }
    void push(T&& new_value)
    {
        {
            std::lock_guard<Mutex> lg(m);
            data.push(std::move(new_value));
        }
        cv.notify_one();
    }
    bool empty() const
    {
        std::lock_guard<Mutex> lg(m);
        return data.empty();
    }

    void pop(T& value)
    {
        std::lock_guard<Mutex> lg(m);
        if (data.empty()) throw empty_stack();

        value = std::move(data.top());
        data.pop();
    }

    std::shared_ptr<T> pop()
    {
        std::lock_guard<Mutex> lg(m);
        if (data.empty()) throw empty_stack();

        auto p = std::make_shared<T>(std::move(data.top()));
        data.pop();
        return p;
    }
    /*
    void pop_and_wait(T& value)
    {
        std::unique_lock<Mutex> ul(m);

        cv.wait(ul, [this] {return !data.empty(); });

        value = std::move(data.top());
        data.pop();
    }
    */
};

struct NoLock
{
    inline void lock() {}
    inline void unlock() {}
};

Stack<int, NoLock> s1;  // ����ȭ�� �ʿ� ���ٴ� �ǹ�.
Stack<int> s2;  // std::mutex�� ����ȭ

int main()
{
    int n = 0;
//    s1.pop_and_wait(n);
}
