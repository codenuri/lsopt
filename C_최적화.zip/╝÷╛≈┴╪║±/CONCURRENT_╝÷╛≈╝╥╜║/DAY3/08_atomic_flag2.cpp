#include <iostream>
#include <atomic>
#include <thread>
#include <mutex>
#include <chrono>
using namespace std::literals;

//bool use_flag = false;
std::atomic<bool> use_flag = false;

void work()
{
//	while (use_flag);	// A
//	use_flag = true;	// B

	while (use_flag.compare_exchange_strong(false, true));
	std::cout << "start. using shared resource" << std::endl;
	std::cout << "end.   using shared resource" << std::endl;
	use_flag = false;

}

int main()
{
	std::thread t1(work), t2(work);

	t1.join();
	t2.join();
}