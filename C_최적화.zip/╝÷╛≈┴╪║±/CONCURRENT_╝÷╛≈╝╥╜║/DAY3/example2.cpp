// example1
#include <thread>
#include <atomic>
#include <iostream>
#include <latch>

// C++20 ���� �߰��� latch �� ���� ������ ���ô�.

class latch
{
	std::atomic<std::size_t> count;
public:
	latch(std::size_t n) : count{ n } {}

	void count_down(std::size_t n = 1)
	{
		// count ����. fetch_sub(n) : n ��ŭ �����ϰ� �������� ������ �˴ϴ�.
		// count = 4, n = 2 ��� fetch_sub(n) ��ȯ���� 4
//		std::size_t cnt = count.fetch_sub(n) - n;
		std::size_t cnt = count.fetch_sub(n, std::memory_order_release) - n;
	
		if (cnt == 0)
		{
			// count �� 0�̹Ƿ� �뺸
			count.notify_all(); 
		}
	}
	void wait()
	{
		while (1)
		{
			int cnt = count.load(); // std::memory_order_seq_cst �̹Ƿ� ����
//			int cnt = count.load(std::memory_order_acquire);
			if (cnt == 0)
				return;    // wait ����
			
			count.wait(cnt);
		}
	}
};

//latch myLatch{ 3 };
std::latch myLatch{ 3 };

void foo()
{
	std::cout << "foo start" << std::endl;
	std::cout << "foo finish" << std::endl;
	
	myLatch.count_down(); // -- count �Դϴ�.

	std::cout << "foo gohome" << std::endl;
}
int main()
{
	std::thread t1(foo), t2(foo), t3(foo);

	myLatch.wait();
	std::cout << "all finish" << std::endl;

	t1.join();
	t2.join();
	t3.join();
}



// latch �� VC++  ����
class latch 
{
private:
    atomic<ptrdiff_t> _Counter;

public:
    static constexpr ptrdiff_t(max)() noexcept {
        return (1ULL << (sizeof(ptrdiff_t) * CHAR_BIT - 1)) - 1;
    }

    constexpr explicit latch(const ptrdiff_t _Expected) noexcept  : _Counter{ _Expected } {
    }

    latch(const latch&) = delete;
    latch& operator=(const latch&) = delete;

    void count_down(const ptrdiff_t _Update = 1) noexcept 
    {
        // TRANSITION, GH-1133: should be memory_order_release
        const ptrdiff_t _Current = _Counter.fetch_sub(_Update) - _Update;

        if (_Current == 0) {
            _Counter.notify_all();
        }
   }

    bool try_wait() const noexcept 
    {
        // TRANSITION, GH-1133: should be memory_order_acquire
        return _Counter.load() == 0;
    }

    void wait() const noexcept 
    {
        for (;;) 
        {
            // TRANSITION, GH-1133: should be memory_order_acquire
            const ptrdiff_t _Current = _Counter.load();
            if (_Current == 0) {
                return;
            }

            _Counter.wait(_Current, memory_order_relaxed);
        }
    }

    void arrive_and_wait(const ptrdiff_t _Update = 1) noexcept 
    {
        const ptrdiff_t _Current = _Counter.fetch_sub(_Update) - _Update;
        if (_Current == 0) 
        {
            _Counter.notify_all();
        }
        else {
            _Counter.wait(_Current, memory_order_relaxed);
            wait();
        }
    }
};