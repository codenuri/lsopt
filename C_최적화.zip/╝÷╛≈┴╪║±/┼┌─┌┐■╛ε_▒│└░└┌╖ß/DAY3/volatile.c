// volatile.c
#include <stdio.h>

int main()
{
    volatile int a = 10;
    a = 20;
    a = 30;
    a = 40;
    
    printf("a = %d\n", a );
}

// gcc volatile.c  -O2

// objdump -d a.out 
