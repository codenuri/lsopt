// main.c
#include <stdio.h>

int asm_main();

int main()
{
    int n = asm_main();

    printf("result = %d\n", n);
}

void f1( int a, int b) { printf("f1 : %d, %d\n", a, b ); }

__attribute__((__stdcall__))  void f2( int a, int b) { printf("f2 : %d, %d\n", a, b); }
__attribute__((__fastcall__)) void f3( int a, int b) { printf("f3 : %d, %d\n", a, b); }
