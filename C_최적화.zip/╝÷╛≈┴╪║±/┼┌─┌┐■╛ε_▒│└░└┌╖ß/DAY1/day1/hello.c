// hello.c

#include <stdio.h>

char s1[] = "abcdefghijk";  // .data section

int main()     // .text section
{
	printf("hello, world\n");
	printf("%s\n", s1);
}

// gcc -o hello hello.c  
