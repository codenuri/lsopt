#include <stdio.h>

int add( int a, int b)
{
    return a + b;
}
double add( double a, double b )
{
    return a + b;
}

int main()
{
    int n = add(1,2);
    double d = add(1.1, 2.2);
}

