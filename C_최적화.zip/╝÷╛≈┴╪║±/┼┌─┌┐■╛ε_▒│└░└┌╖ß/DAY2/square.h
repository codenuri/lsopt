// square.h

extern "C" int square(int);

// gcc -c square.c
