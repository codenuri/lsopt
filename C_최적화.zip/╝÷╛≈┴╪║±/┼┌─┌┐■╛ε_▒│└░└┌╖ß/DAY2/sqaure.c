// square.c

int square( int a )
{
    return a * a;
}

