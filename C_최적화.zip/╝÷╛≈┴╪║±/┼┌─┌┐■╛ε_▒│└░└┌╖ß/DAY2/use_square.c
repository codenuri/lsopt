// use_square.c
#include <stdio.h>
#include "square.h"

int main()
{
    int n = square(3);

    printf("%d\n", n);
}



