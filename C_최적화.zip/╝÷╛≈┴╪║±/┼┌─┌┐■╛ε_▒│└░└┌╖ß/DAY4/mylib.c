// mylib.c

#include <stdio.h>

int add( int a, int b)
{
	printf("mylib.so   add\n");
	return a + b;
}

__attribute__((__stdcall__)) int add2( int a, int b)
{
	printf("mylib.so  add2\n");
	return a + b;
}

__attribute__((constructor)) void ctor()
{
	printf("mylib.so  ctor\n");
}
__attribute__((destructor)) void dtor()
{
	printf("mylib.so  dtor\n");
}

// gcc -shared -fPIC -o libmy.so  mylib.c