#include <stdio.h>
#include <Windows.h>

int main()
{
	char passwd[256];

	printf("pid : %d, passwd addr : %p\n", GetCurrentProcessId(),
											passwd);

	while( 1 )
	{
		printf("input pass wd >> ");

		gets(passwd);
	}
}
