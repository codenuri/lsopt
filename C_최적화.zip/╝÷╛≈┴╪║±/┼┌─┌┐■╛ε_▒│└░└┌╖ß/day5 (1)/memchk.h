#include <stdio.h>
#include <string.h>

typedef struct _mem_info
{
    char  file[256];
    int   line;
    void *addr;
} MEM_INFO;

MEM_INFO _mem[10000];
int      count = 0;

void *my_malloc( size_t sz, char *file, int line )
{
    void* p = malloc(sz);
	
    _mem[count].addr = p;
    _mem[count].line = line;
    strcpy(_mem[count].file, file);

    ++count;
    return p;
}

void my_free(void *p)
{
    int i = 0;

    for ( i = 0; i < count; i++ )
    {
	if ( _mem[i].addr == p )
	{
	    _mem[i] = _mem[count-1];
	    free(p);
	    --count;
	    break;
	}
    }
}

int Main();

int main()
{
    int i = 0;
    int ret = Main();
    if ( count == 0 ) 
    {
	printf("no memory leak...\n");
	return 0;
    }
 
    printf("found %d memory leak..\n", count );
    for ( i = 0; i < count; i++ )
    {
	printf("%s(%d) : %p\n", _mem[i].file, _mem[i].line, _mem[i].addr);
    }
}

#define main Main

/*
__attribute__((destructor)) void check_memory_leak()
{
    int i = 0;

    if ( count == 0 ) 
    {
	printf("no memory leak...\n");
	return;
    }
    
    printf("found %d memory leak..\n", count );

    for ( i = 0; i < count; i++ )
    {
	printf("%s(%d) : %p\n", _mem[i].file, _mem[i].line, _mem[i].addr);
    }
}
*/

#define malloc(x) my_malloc(x, __FILE__, __LINE__)
#define free(x)   my_free(x)

//int *p = malloc(100);



























