#include <stdio.h>
#include <vector>
// grow size : 동적 배열을 만들때 한개가 추가될경우 단, 한개만 늘리지 말고
//	       grow size에 설정된 크기로 늘리자. 대부분 1.5 ~ 2.0 배로 확대.@!

int main()
{
    int sz = 10;
    int x[sz]; // 배열의 크기를 변수로 ?? C89안된다. C99된다.
    	       // 그런데, VC, BORANDC  : 모두 안된다.  GCC : 된다.

    // 하지만 배열은 실행중 크기를 바꿀수 없다.
    // 그래서 동적 배열이라는 자료 구조를 사용한다.

    // 메모리의 효율적 관리를 위한 C++ vector기술
    std::vector<int> v(10); // 10개의 메모리를 잡는다.

   // v.resize(5); // 5개로 줄인다.

    v.push_back(1);// 끝에 한개 추가한다.

    printf("%d\n", v.size()); // 11
    printf("%d\n", v.capacity()); // 15

    v.free_extra(); // capacity의 여유 공간을 제거한다.
}

