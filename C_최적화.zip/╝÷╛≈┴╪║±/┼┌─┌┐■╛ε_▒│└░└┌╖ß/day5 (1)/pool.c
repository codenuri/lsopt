#include <stdio.h>

// memory pool

typedef struct _node1
{
    char data[32];
    struct _node1 *next;
} NODE1;  // 36

typedef struct _node2
{
    char data[24];
    struct _node2 *next;
} NODE2;  // 28

#define POOL_SIZE 500

typedef struct _pool_node
{
    struct _pool_node *next;
} POOL_NODE;

POOL_NODE *free = 0;
int elmen_size = 0;

void init_pool( int element_size )
{
    int i = 0;
    
    free = (POOL_NODE*)malloc( element_size * POOL_SIZE );

    elmen_size = element_size;

    // make single linked list..
    for (i = 0; i < POOL_SIZE ; i++ )
    {
	((POOL_NODE*)((char*)free + elem_size*i)))->next = &((char*)free +  (elem_size*i+i));
    }
}
//---------------------------------------------
void* pool_alloc()
{
    // return first node..
    POOL_NODE *temp = free;
    free = free->next;
    return temp;
}
void pool_free( void *p )
{
    POOL_NODE *temp = (POOL_NODE*)p;
    temp->next = free;
    free = temp;
}

int main()
{
    NODE1 *p1 = (NODE*)malloc(sizeof(NODE1));
    NODE2 *p2 = (NODE*)malloc(sizeof(NODE2));
    NODE1 *p4, *p5, *p6;

    init_pool( sizeof(NODE1));
    p4 = pool_alloc();
    p5 = pool_alloc();
    pool_free(p5);
    p6 = pool_alloc();
    printf("%p\n", p6); // p6 is same p5
}















