#include <stdio.h>
#include "memchk.h"

// find memory leak...

int main()
{
    void *p1 = malloc(100);
    void *p2 = malloc(100);
    void *p3 = malloc(100);

    free(p2);
}

