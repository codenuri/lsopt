#include <stdio.h>
#include <unistd.h>
#include <sys/mman.h>
#include <vector>

int main()
{
	// memory 

}

/*
// .text section. excutable
void foo()
{
    printf("hello, foo\n");
}
typedef void(*F)();

void allow_execute(void *addr)
{
    long pagesize = (int)sysconf(_SC_PAGESIZE);
    char *p  = (char*)((long)addr & ~ (pagesize-1L));
    printf("addr : %p, p : %p\n", addr, p ); 
    printf("page size : %d\n", pagesize);

    mprotect( p, pagesize*100, PROT_READ | PROT_WRITE | PROT_EXEC );
}

int main()
{
    //void *p1 = malloc(1000);
    char p1[1000];

    F p2 = 0;
    memcpy( p1, &foo, 1000);

    p2 = (F)p1;
    allow_execute( p1 );
    p2(); // ???
}
*/










