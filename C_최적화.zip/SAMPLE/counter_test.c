#include "counter.h"

#pragma pack(1)
struct PACKET
{
	char cmd;
	int data;
};

int main()
{
	CHECK(START);

	int s = 0;
	struct PACKET pack;

	for (int i = 0; i < 20000000; i++)
	{
		s = s + i;
		pack.data = s;
	}

	CHECK(END);
}