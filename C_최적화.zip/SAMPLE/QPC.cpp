#include <windows.h>
#include <stdio.h>
#include <thread>
#include <chrono>

int main()
{
	LARGE_INTEGER freq, start, end;

	QueryPerformanceFrequency(&freq);
	QueryPerformanceCounter(&start);

	std::this_thread::sleep_for(std::chrono::milliseconds(2000));

	QueryPerformanceCounter(&end);

	double time = (end.QuadPart - start.QuadPart) / (double)freq.QuadPart;

	printf("%lf\n", time);

}
