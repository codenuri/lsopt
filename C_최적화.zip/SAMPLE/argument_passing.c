// call by value vs call by pointer

struct big
{
	int arr[1000];
	char str[1000];
};

void modify(struct big arg)		// bad
{
}

void modify(struct big* arg)	// good
{
}
