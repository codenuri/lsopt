#include <stdio.h>

int main()
{
	int n1 = 10;
	int* p = &n1;
	int n2 = 101;

	printf("&n1 : %p\n", &n1);
	printf("p   : %p\n", &p);
	printf("&n2 : %p\n", &n2);

	--p;
	--p;
	--p;
	--p;

	printf("p   : %p\n", p);

	*p = 20;

	printf("%d\n", n1);
	printf("%d\n", *p);
}