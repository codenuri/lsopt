#include "counter.h"
#define LOOPCOUNT 1000000

typedef struct _packet1
{
	char cmd1;
	char cmd2;

	int data;
} PACKET1;

#pragma pack(1)
typedef struct _packet2
{
	char cmd1;
	char cmd2;
	int data;
} PACKET2; 
       
void f1()  
{  
	PACKET1 packet = { 0,0 };
	for (int i = 0; i < LOOPCOUNT; i++)
	{
		packet.data = i;
	} 
}
    
void f2()
{
	PACKET2 packet = { 0,0 };
	for (int i = 0; i < LOOPCOUNT; i++)
	{
		packet.data = i;
	} 
}

int main()
{
	printf("%d\n", sizeof(PACKET1));
	printf("%d\n", sizeof(PACKET2));

	CHECK(START);
	f1();
	CHECK(LAB);
	f2();
	CHECK(END);
}