#include <stdio.h>

int main()
{
	char* s1 = "hello";
//	*s1 = 'A';
	printf("finish main\n");
}