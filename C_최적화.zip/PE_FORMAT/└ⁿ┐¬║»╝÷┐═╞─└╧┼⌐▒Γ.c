#include <stdio.h>

//int x[10000] = { 0 };
//int x[10000];

int x[10000] = { 1,2,3 };
int main()
{
	x[0] = 10;
}