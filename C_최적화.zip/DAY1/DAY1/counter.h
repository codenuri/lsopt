#pragma once
#include <stdio.h>

#ifdef __cplusplus
extern "C" {
#endif

	extern const int START;
	extern const int END;
	extern const int LAB;

	void CHECK(const int check);


#ifdef __cplusplus
}
#endif
