#include <windows.h>
#include <stdio.h>
#include "counter.h"

const int START = 1;
const int END = 2;
const int LAB = 3;

void CHECK(const int check)
{
	static LARGE_INTEGER freq, start, end;

	if (check == START)
	{
		QueryPerformanceFrequency(&freq);
		QueryPerformanceCounter(&start); // GetTickCount()
	}
	else
	{
		QueryPerformanceCounter(&end);

		printf("==================> %lf\n",
					(end.QuadPart - start.QuadPart) / (double)freq.QuadPart);
		
		if (check == LAB)
		{
			QueryPerformanceCounter(&start);
		}
	}
}

