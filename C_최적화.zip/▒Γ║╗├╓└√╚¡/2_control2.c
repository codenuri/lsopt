// if-else if ���� switch �� �� �� ����ȭ �ȴ�.
void bad()
{
    int i = 8;

    if (i == 1) {}
    else if (i == 2) {}
    else if (i == 3) {}
    else if (i == 4) {}
    else if (i == 5) {}
    else if (i == 6) {}
    else if (i == 7) {}
    else if (i == 8) {}
}

void good()
{
    int i = 8;
    switch (i)
    {
    case 1: break;
    case 2: break;
    case 3: break;
    case 4: break;
    case 5: break;
    case 6: break;
    case 7: break;
    case 8: break;
    }
}

int main()
{
    bad();
    good();
}