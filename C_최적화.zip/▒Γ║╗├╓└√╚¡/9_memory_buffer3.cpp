#include "counter.h"
#include <vector>
#include <list>

#define INPUT_COUNT 100000

int get_input()
{
	static int num = 0;
	++num;
	if (num == INPUT_COUNT)
		num = 0;
	return num;
}

void f1()
{
	int n = 0;
	std::vector<int> c;
	
	while (1)
	{
		n = get_input();

		if (n == 0)
			break;

		c.push_back(n);
	}
}

void f2()
{
	int n = 0;
	std::list<int> c;

	while (1)
	{
		n = get_input();

		if (n == 0)
			break;

		c.push_back(n);
	}
}

int x[INPUT_COUNT];

void f3()
{
	int n = 0;

	int i = 0;
	while (1)
	{
		n = get_input();

		if (n == 0)
			break;

		x[i++] = n;
	}
}

int main()
{
	CHECK(START);
	f1();
	CHECK(LAB);
	f2();
	CHECK(LAB);
	f3();
	CHECK(END);
}


