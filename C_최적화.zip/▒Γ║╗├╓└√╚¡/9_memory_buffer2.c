#include "counter.h"
#define INPUT_COUNT 100000
#define START_SIZE 4
#define GROW  1

int get_input()
{
	static int num = 0;
	++num;
	if (num == INPUT_COUNT)
		return -1;
	return num;
}

void f1()
{
	int size = START_SIZE;
	int* score = (int*)malloc(sizeof(int) * size);

	int count = 0;
	int n = 0;

	while (1)
	{
		n = get_input();

		if (n == -1)
			break;

		score[count] = n; // ����
		++count;

		if (count == size)
		{
			int* tmp = (int*)malloc(sizeof(int) * (size + GROW));

			memcpy(tmp, score, sizeof(int) * size);

			free(score);
			score = tmp;

			size = size + GROW;

		}
	}
	printf("�Էµ� ����     : %d\n", count);
	printf("�Ҵ�� ���� ũ�� : %d\n", size);

	free(score);
}

int main()
{
	CHECK(START);
	f1();
	CHECK(END);
}


