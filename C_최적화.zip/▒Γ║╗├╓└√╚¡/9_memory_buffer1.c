#include <stdio.h>

int main()
{
	int score[4] = { 0 };
	int n = 0;
	int count = 0;

	while (1)
	{
		scanf_s("%d", &n);

		if (n == -1) break;

		score[count++] = n;
	}
}