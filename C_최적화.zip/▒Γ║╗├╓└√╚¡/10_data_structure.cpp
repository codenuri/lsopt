#include "counter.h"
#include <set>
#include <unordered_set>
#include <vector>

#define COUNT 1000000

std::vector<int> v;
std::set<int> tree;
std::unordered_set<int> hash;

void init()
{
	for (int i = 0; i < COUNT; i++)
		v.push_back(rand());
}

void fill_tree()
{
	for (int i = 0; i < COUNT; i++)
		tree.insert(v[i]);
}

void fill_hash()
{
	for (int i = 0; i < COUNT; i++)
		hash.insert(v[i]);
}

void find_tree()
{
	for (int i = 0; i < 10000; i++)
	{
		tree.find(v[i]);
	}
}

void find_hash()
{
	for (int i = 0; i < 10000; i++)
	{
		hash.find(v[i]);
	}
}

int main()
{
	init();
	CHECK(START);
	fill_tree();
	CHECK(LAB);
	fill_hash();
	CHECK(LAB);
	find_tree();
	CHECK(LAB);
	find_hash();
	CHECK(END);

}