#include <stdio.h>

int a1 = 0;
int a2 = 0;

#ifdef __cplusplus
 int b1 = 0;
alignas(4096)int b2 = 0;
#else
_Alignas(64) int b1 = 0;
_Alignas(64) int b2 = 0;
#endif
int main()
{
	printf("%p\n", &a1);
	printf("%p\n", &a2);
	printf("%p\n", &b1);
	printf("%p\n", &b2);
}