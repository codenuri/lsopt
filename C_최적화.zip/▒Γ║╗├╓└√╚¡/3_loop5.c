#include "counter.h"

// �ݺ������� �Լ� ȣ�� ����

void bad()
{
	char s[] = "to be or not to be";

	for (int i = 0; i < strlen(s); i++)
	{
		if (s[i] == ' ')
			s[i] = '*';
	}
}

void good()
{
	char s[] = "to be or not to be";

	int sz = strlen(s);

	for (int i = 0; i < sz; i++)
	{
		if (s[i] == ' ')
			s[i] = '*';
	}
}

int main()
{
	bad();
	good();
}