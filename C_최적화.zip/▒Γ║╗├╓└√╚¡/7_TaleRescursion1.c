#include "counter.h"

int sum1(int n)
{
	if (n == 1) return 1;
	return n + sum1(n - 1);
}

int sum2Tail(int n, int acc)
{
	if (n == 1) return acc;
	return sum2Tail(n - 1, acc + n);
}

int sum2(int n)
{
	return sum2Tail(n, 1);
}

int main()
{
	int ret1 = 0;
	int ret2 = 0;
	int cnt = 500000;

	CHECK(START);
//	ret1 = sum1(cnt);
	CHECK(LAB);
	ret2 = sum2(cnt);
	CHECK(END);

	printf("%d\n", ret1);
	printf("%d\n", ret2);
}