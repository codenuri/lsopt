// lock-free stack
