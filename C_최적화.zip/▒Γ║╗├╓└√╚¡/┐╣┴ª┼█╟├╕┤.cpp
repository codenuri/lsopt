#include "counter.h"

void bad()
{
}

void good()
{
}

int main()
{
	bad();
	good();
}