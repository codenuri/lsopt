
void bad()
{
	int n = 10;

	if (n & 1)
	{
		n = 0x11;
	}
	else
	{
		n = 0x12;
	}
}
void good()
{
	int n = 10;

	if (n & 1)
	{
		n = 0x11;
	}
	else
	{
		n = 0x12;
	}
}