﻿#include <stdio.h>

int Factorial1(int n)
{
	if (n == 1) return 1;

	return n * Factorial1(n - 1);
}
/*
int Factorial(int n)
{
	if (n == 1) return 1;

	int result = Factorial(n - 1);

	return n * result;
}
*/

int FactorialTail(long long n, long long acc)
{
	if (n == 1) return acc;
	return FactorialTail(n - 1, acc + n); 
}

long long Factorial2(long long n)
{
	return FactorialTail(n, 1);

}

int FactorialTail(int n) 
{ 
	int acc = 1;	
	do 
	{ 
		if (n == 1) return;		
		acc = acc * n;		
		n = n - 1; 
	} 
	while (true); 
}

int main()
{
//	int n = Factorial1(150000);
	long long n = Factorial2(5000);
//	int n = Factorial2(5);	//  FactorialTail(5, 1)
							//  FactorialTail(5, 1)
							//		FactorialTail(4, 5)
							//			FactorialTail(3, 20)
							//				FactorialTail(2, 60)
							//					FactorialTail(1, 120) - return 120

	printf("%lld\n", n);
}