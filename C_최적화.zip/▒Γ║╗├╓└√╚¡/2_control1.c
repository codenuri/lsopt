// binaray breakdown
void bad()
{
    int i = 8;
    for (int j = 0; j < LOOPCOUNT; j++)
    {
        if (i == 1) {}
        else if (i == 2) {}
        else if (i == 3) {}
        else if (i == 4) {}
        else if (i == 5) {}
        else if (i == 6) {}
        else if (i == 7) {}
        else if (i == 8) {}
    }
}

void good()
{
    int i = 8;
    for (int j = 0; j < LOOPCOUNT; j++)
    {
        if (i <= 4) {
            if (i <= 2) {
                if (i == 1) {
                    /* i is 1 */
                }
                else {
                    /* i must be 2 */
                }
            }
            else {
                if (i == 3) {
                    /* i is 3 */
                }
                else {
                    /* i must be 4 */
                }
            }
        }
        else {
            if (i <= 6) {
                if (i == 5) {}  // i is 5 
                else {}         // i must be 6                 
            }
            else {
                if (i == 7) {} // i is 7 
                else {}        // i must be 8                 
            }
        }
    }
}

int main()
{
    bad();
    good();
}