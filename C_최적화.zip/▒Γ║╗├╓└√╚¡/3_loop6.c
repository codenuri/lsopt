
// for vs while vs do~while
void f1()
{
	int n = 0;
	int i = 0;
	
	for (i = 0; i < 100; i++)
	{
		n = 0x11;
	}
}

void f2()
{
	int n = 0;
	int i = 0;

	while( i < 100 )
	{
		n = 0x11;

		i++;
	}
}

void f3()
{
	int n = 0;
	int i = 0;

	do
	{
		n = 0x11;
		i++;
	}while (i < 100)
}

int main()
{
	f1 ();
	f2 ();
	f3();
}