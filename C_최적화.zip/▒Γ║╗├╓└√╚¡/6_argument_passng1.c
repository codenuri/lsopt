// call by value vs call by pointer

struct big
{
	int arr[1000];
	char str[1000];
};

void bad(struct big arg)	 // bad
{
}

void good(struct big* arg)	// good
{
}

int main()
{
	struct big b;
	bad(b);
	good(&b);

}

