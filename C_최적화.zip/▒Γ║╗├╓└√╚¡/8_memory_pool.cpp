#include <stdio.h>
#include <stdlib.h>

typedef struct _bullet
{
	int x;
	union
	{
		int y;
		struct _bullet* next;
	};
} bullet;
 
bullet* head = 0;

void create_pool(int size)
{
	head = (bullet*)malloc(sizeof(bullet) * size);
	
	for (int i = 0; i < size-1; i++)
		head[i].next = &head[i + 1];
}

void destroy_pool()
{
	free(head);
}

bullet* alloc_pool()
{
	bullet* temp = head;
	head = head->next;
	return temp;
}

void free_pool(bullet* p)
{
	p->next = head;
	head = p;
}

int main()
{
	create_pool(200);

	bullet* p1 = alloc_pool();
	bullet* p2 = alloc_pool();
	bullet* p3 = alloc_pool();
	printf("%p\n", p1);
	printf("%p\n", p2);
	printf("%p\n", p3);

	free_pool(p1);
	free_pool(p2);

	bullet* p4 = alloc_pool();
	printf("%p\n", p4);

	destroy_pool();
}