#include <stdio.h>

// PE
int x[10000] = { 0 }; 	

int main()
{
	x[0] = 10;
}

