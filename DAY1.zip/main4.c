// main3.c - main1.c ����

#include <stdio.h>

#ifdef __unix__
#define asm_main _asm_main
#endif

int asm_main(void);

int main()
{
    int n = asm_main();

    printf("result : %d\n", n);
}

void __cdecl    f1(int a, int b) { printf("f1 : %d, %d\n", a, b); }
void __stdcall  f2(int a, int b) { printf("f2 : %d, %d\n", a, b); }
void __fastcall f3(int a, int b) { printf("f3 : %d, %d\n", a, b); }
void __fastcall f4(int a, int b, int c)
{
    printf("f4 : %d, %d, %d\n", a, b, c);
}