#include "counter.h"

#define LOOPCOUNT 100000


// ��ũ�� �Լ�
#define add1(a, b) ((a) + (b))


// �Ϲ� �Լ�.
int add2(int a, int b)
{
	return a + b;
}


int main()
{
	int n1 = 0, n2 = 0;
	int x = 10, y = 20;

	CHECK(START);

	for (int i = 0; i < LOOPCOUNT; i++)
	{
		n1 = add1(x, y);
	}

	CHECK(LAB);

	for (int i = 0; i < LOOPCOUNT; i++)
	{
		n2 = add2(x, y);
	}

	CHECK(END);

	printf("%d, %d\n", n1, n2);
}