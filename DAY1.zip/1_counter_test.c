#include "counter.h"

long long sum1(long long n)
{
	long long s = 0;
	for (long long i = 0; i <= n; i++)
		s += i;
	return s;
}

double sum2(double n)
{
	double s = 0;
	for (double i = 0; i <= n; i++)
		s += i;
	return s;
}

int main()
{
	int cnt = 1000000;
	sum1(cnt);
	sum2(cnt);

	printf("%lld\n", sum1(cnt));
	printf("%lf\n", sum2(cnt));
}
