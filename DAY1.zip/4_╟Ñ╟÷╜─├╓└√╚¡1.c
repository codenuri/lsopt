
int main()
{
	int day = 30;
	int a = 0, b = 0, c = 0, d = 0, x = 0;

	// 1. ����� ��ƶ�.
	int cnt1 = 60 * day * 24 * 31; 
	


	// 2. ǥ������ �ܼ��ϰ�.
	// ax^3 + bx^2 + cx + d
	int y1 = a * x * x * x + b * x * x + c * x + d;  
	int y2 = (((a * x + b) * x + c) * x + d);        


	// 3. increment 
	int n1 = ++a;
	int n2 = b++; 


	for (int i = 0; i < 10; ?? ) 
	{						
	}
}
