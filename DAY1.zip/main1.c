#include <stdio.h>

int add(int a, int b)
{
	int c = 0;
	c = a + b;
	return c;
}
int main()
{
	int n = 0;

	__asm
	{
		push 2
		push 1
		call add
		add  esp, 8
		mov n, eax
	}

	printf("%d\n", n);
}