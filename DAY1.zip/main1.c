#include <stdio.h>

int add(int a, int b)
{
	int c = 0;
	c = a + b;
	return c;
}
int main()
{
	int n = add(1, 2);

	printf("%d\n", n);
}